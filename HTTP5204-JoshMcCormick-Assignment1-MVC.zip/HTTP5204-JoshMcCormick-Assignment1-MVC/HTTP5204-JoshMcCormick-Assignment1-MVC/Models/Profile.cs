﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HTTP5204_JoshMcCormick_Assignment1_MVC.Models
{
    public class Profile
    {
        public string Name { get; set; }
        public string Student_Number { get; set; }
        public string Program { get; set; }
    }
}