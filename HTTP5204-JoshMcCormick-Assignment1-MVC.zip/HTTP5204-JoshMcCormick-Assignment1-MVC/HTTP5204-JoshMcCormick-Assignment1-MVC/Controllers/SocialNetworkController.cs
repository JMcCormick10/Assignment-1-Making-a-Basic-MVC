﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HTTP5204_JoshMcCormick_Assignment1_MVC.Models;

namespace HTTP5204_JoshMcCormick_Assignment1_MVC.Controllers
{
    public class SocialNetworkController : Controller
    {
        // GET: SocialNetwork
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Josh_McCormick()
        {
            Profile Josh = new Profile();

            Josh.Name = "Josh McCormick";
            Josh.Student_Number = "N00469105";
            Josh.Program = "Web Development";

            return View(Josh);
        }
    }
}